export const BASE_URL = "https://waycool-project1-backend.herokuapp.com"

const API_BASE_URL = `${BASE_URL}/api`
export const homepageApi = `${API_BASE_URL}/homepage`
export const productsApi = `${API_BASE_URL}/products`